document.addEventListener("DOMContentLoaded", function () {
    const ctx = document.getElementById("stressChart").getContext("2d");

    let stressChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Your Stress Level"],
            datasets: [{
                label: "Stress Level (%)",
                data: [0], // Default value
                backgroundColor: "rgba(255, 99, 132, 0.5)",
                borderColor: "rgba(255, 99, 132, 1)",
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true, max: 100 }
            }
        }
    });

    window.calculateStress = function () {
        const sleepHours = parseFloat(document.getElementById("sleepHours").value);
        const heartRate = parseInt(document.getElementById("heartRate").value);
        const bloodPressure = parseInt(document.getElementById("bloodPressure").value);

        if (isNaN(sleepHours) || isNaN(heartRate) || isNaN(bloodPressure)) {
            alert("Please enter valid values for all fields.");
            return;
        }

        let stressScore = 0;

        // Stress Calculation Logic
        if (sleepHours < 5) stressScore += 40;
        else if (sleepHours < 7) stressScore += 20;
        else stressScore += 5;

        if (heartRate > 100) stressScore += 30;
        else if (heartRate > 80) stressScore += 20;
        else stressScore += 5;

        if (bloodPressure > 140) stressScore += 30;
        else if (bloodPressure > 120) stressScore += 20;
        else stressScore += 5;

        stressScore = Math.min(stressScore, 100); // Max stress level is 100%

        document.getElementById("stressLevel").innerText = `${stressScore}% Stress Level`;

        // AI Recommendations
        let recommendation = "Your health looks stable! Keep maintaining a healthy lifestyle.";
        if (stressScore > 80) {
            recommendation = "⚠️ High stress! Try deep breathing, meditation, and reduce caffeine intake.";
        } else if (stressScore > 60) {
            recommendation = "Moderate stress detected. Consider relaxation exercises and better sleep habits.";
        } else if (stressScore > 40) {
            recommendation = "Slight stress. Try light exercise or a short break.";
        }
        
        document.getElementById("recommendation").innerText = recommendation;

        // Update Chart
        stressChart.data.datasets[0].data = [stressScore];
        stressChart.update();
    };
});
